package com.example.justiceleague;

public class MyData {

    static String[] nameHero = {"Batman", "Flash", "Green Lantern",
    "Hawk girl", "Martian Manhunter", "Superman", "Wonder Woman"};

    static String[] privateName = {"Bruce Wayne", "Wally West", "Jordan Hal",
    "Shayera Hol", "J'onn J'onns", "Clark Kent", "Diana Prince"};

    static Integer[] drawableArray = {R.drawable.batman, R.drawable.flash, R.drawable.green_lantern,
    R.drawable.hawkgirl, R.drawable.man_martian, R.drawable.superman, R.drawable.wonder_woman};

    static Integer[] id_ = {0,1,2,3,4,5,6};

    static String[] Description = {"Batman - Bruce Wayne, a billionaire industrialist and philanthropist. As a child, Wayne witnessed the murder of his parents, which motivated him ever since to seek revenge and to declare a brutal war on crime - an oath mixed with a high ideal of justice. Wayne trains himself physically and mentally, donning a bat-like costume to fight crime",
    "Flash - Barry Allen is a police scientist who got his powers after a shelf full of chemicals fell on him as a result of a lightning strike. He discovered that he could run at super speeds and had similar reflexes. He wore a red suit with a lightning bolt on the chest, called himself the Flash after his childhood hero Jay Garrick, and fought crime",
    "Green Lantern - Hal Jordan, a test pilot who was given a power ring by a dying alien, Abin Sur, and became a member of the Green Patrol Force, an intergalactic police force overseen by the Guardians of the Universe. The power of the rings was resistant to anything other than yellow, and this was due to a natural flaw in the ring.",
    "Hawk girl - Hawkgirl from The Golden Age was Shiara Sanders Hall, the reincarnation of an Egyptian princess named Chai-Era and partner of Carter Hall, Hawkman from The Golden Age",
    "Martian Manhunter - An alien born from Mars who came to Earth by mistake and is endowed with special powers that give him the abilities of a superhero. He usually appears as a green human figure wearing a cloak, and disguises himself as a detective named John Jones with the help of his shape-shifting ability",
    "Superman - Superman was born Kal-El on the fictional planet Krypton. He was launched in a spaceship to Earth by his father, the scientist Jor-El, before the planet was destroyed. A couple of farmers from Kansas found Kal-El, adopted him and called him Clark Kent",
    "Wonder Woman - Wonder Woman is Diana, the princess of the Amazons (based on Greek mythology) and their ambassador to the world. She was designed by Marston to have superhuman abilities and tools given to her by the Olympian gods, in order to bring peace, love and brotherhood to a divided world. In the latest adaptation of the character, she received her characteristics and powers from the gods - beauty like Aphrodite, wisdom like Athena, physical strength like Demeter, and animal instincts like Artemis."};

}
